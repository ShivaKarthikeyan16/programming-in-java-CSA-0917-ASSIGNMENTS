import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class LibrarySearchScreen extends JFrame {
    private final JTextField query=new JTextField(22);
    private final JComboBox<String> category=new JComboBox<>(new String[]{"All","Book","Author","Subject"});
    private final DefaultListModel<String> model=new DefaultListModel<>();
    private final JList<String> results=new JList<>(model);
    private final JLabel status=new JLabel("Enter a search term.");
    public LibrarySearchScreen() {
        super("Campus Library Search");
        setLayout(new BorderLayout(8,8));
        JLabel title=new JLabel("Library Search",SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(20f)); add(title,BorderLayout.NORTH);
        JPanel center=new JPanel(new BorderLayout(6,6));
        JPanel search=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton find=new JButton("Search");
        search.add(new JLabel("Search")); search.add(query); search.add(category); search.add(find);
        center.add(search,BorderLayout.NORTH);
        results.setVisibleRowCount(12); center.add(new JScrollPane(results),BorderLayout.CENTER);
        add(center,BorderLayout.CENTER);
        JPanel bottom=new JPanel(new BorderLayout());
        JPanel buttons=new JPanel(new FlowLayout());
        buttons.add(new JButton("Prev")); buttons.add(new JButton("Next")); buttons.add(new JButton("Reserve"));
        bottom.add(buttons,BorderLayout.CENTER); bottom.add(status,BorderLayout.SOUTH);
        add(bottom,BorderLayout.SOUTH);
        find.addActionListener(e -> search());
        query.addActionListener(e -> search());
        setDefaultCloseOperation(EXIT_ON_CLOSE); setSize(650,430); setLocationRelativeTo(null);
    }
    private void search() {
        model.clear();
        if(query.getText().trim().isEmpty()){ status.setText("Please enter a search term."); return; }
        model.addElement("Sample result 1 — "+query.getText());
        model.addElement("Sample result 2 — "+category.getSelectedItem());
        status.setText("2 sample results displayed. Connect the library data source for live records.");
    }
    public static void main(String[] a){ SwingUtilities.invokeLater(() -> new LibrarySearchScreen().setVisible(true)); }
}
