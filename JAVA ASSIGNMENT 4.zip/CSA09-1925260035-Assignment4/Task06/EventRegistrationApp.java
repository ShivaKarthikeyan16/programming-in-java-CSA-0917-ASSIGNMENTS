import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class EventRegistrationApp extends JFrame {
    private final JTextField studentId=new JTextField(12), studentName=new JTextField(16);
    private final JComboBox<String> event=new JComboBox<>(new String[]{"Tech Fest","Cultural Night","Sports Meet"});
    private final DefaultTableModel model=new DefaultTableModel(new String[]{"ID","Student","Event","Registered At"},0);
    private final JTable table=new JTable(model);
    private final JTextField filter=new JTextField(12);
    private final RegistrationService service=new RegistrationService(new RegistrationDAO());
    public EventRegistrationApp(){
        super("Campus Event Registration");
        setLayout(new BorderLayout(8,8));
        JMenuBar bar=new JMenuBar(); JMenu file=new JMenu("File"); JMenuItem refresh=new JMenuItem("Refresh"), exit=new JMenuItem("Exit");
        refresh.addActionListener(e->loadPage(0)); exit.addActionListener(e->dispose()); file.add(refresh);file.add(exit);bar.add(file);setJMenuBar(bar);
        JPanel form=new JPanel(new FlowLayout(FlowLayout.LEFT));form.setBorder(BorderFactory.createTitledBorder("Student Registration"));
        JButton register=new JButton("Register");form.add(new JLabel("Student ID"));form.add(studentId);form.add(new JLabel("Name"));form.add(studentName);form.add(event);form.add(register);
        JPanel tools=new JPanel(new FlowLayout(FlowLayout.LEFT));JButton apply=new JButton("Filter");tools.add(new JLabel("Event filter"));tools.add(filter);tools.add(apply);
        JPanel north=new JPanel(new BorderLayout());north.add(form,BorderLayout.NORTH);north.add(tools,BorderLayout.SOUTH);add(north,BorderLayout.NORTH);
        add(new JScrollPane(table),BorderLayout.CENTER);
        register.addActionListener(e->register());apply.addActionListener(e->loadPage(0));
        setDefaultCloseOperation(EXIT_ON_CLOSE);setSize(850,500);setLocationRelativeTo(null);loadPage(0);
    }
    private void register(){
        String id=studentId.getText().trim(), name=studentName.getText().trim(), ev=(String)event.getSelectedItem();
        if(id.isEmpty()||name.isEmpty()){JOptionPane.showMessageDialog(this,"Student ID and name are required.");return;}
        new SwingWorker<Void,Void>(){
            protected Void doInBackground() throws Exception{service.register(id,name,ev);return null;}
            protected void done(){try{get();JOptionPane.showMessageDialog(EventRegistrationApp.this,"Registration successful.");loadPage(0);}
                catch(Exception ex){JOptionPane.showMessageDialog(EventRegistrationApp.this,rootMessage(ex),"Registration error",JOptionPane.ERROR_MESSAGE);}}
        }.execute();
    }
    private void loadPage(int offset){
        String f=filter.getText().trim();
        new SwingWorker<List<String[]>,Void>(){
            protected List<String[]> doInBackground() throws Exception{return service.list(f,100,offset);}
            protected void done(){try{model.setRowCount(0);for(String[] r:get())model.addRow(r);}
                catch(Exception ex){JOptionPane.showMessageDialog(EventRegistrationApp.this,rootMessage(ex),"Load error",JOptionPane.ERROR_MESSAGE);}}
        }.execute();
    }
    private static String rootMessage(Throwable t){while(t.getCause()!=null)t=t.getCause();return t.getMessage();}
    public static void main(String[] a){SwingUtilities.invokeLater(()->new EventRegistrationApp().setVisible(true));}
}
class RegistrationService {
    private final RegistrationDAO dao; RegistrationService(RegistrationDAO d){dao=d;}
    void register(String id,String name,String event)throws SQLException{
        if(id.isBlank()||name.isBlank())throw new IllegalArgumentException("All fields are required.");
        dao.insert(id,name,event);
    }
    List<String[]> list(String event,int limit,int offset)throws SQLException{return dao.fetch(event,limit,offset);}
}
class RegistrationDAO {
    private final String url=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/campus_events");
    private final String user=System.getenv().getOrDefault("DB_USER","root");
    private final String pass=System.getenv().getOrDefault("DB_PASSWORD","");
    void insert(String id,String name,String event)throws SQLException{
        String sql="INSERT INTO registrations(student_id,student_name,event_name) VALUES(?,?,?)";
        try(Connection c=DriverManager.getConnection(url,user,pass);PreparedStatement p=c.prepareStatement(sql)){
            p.setString(1,id);p.setString(2,name);p.setString(3,event);p.executeUpdate();
        }
    }
    List<String[]> fetch(String event,int limit,int offset)throws SQLException{
        String sql="SELECT student_id,student_name,event_name,registered_at FROM registrations "+
          (event.isEmpty()?"":"WHERE event_name=? ")+"ORDER BY registered_at DESC LIMIT ? OFFSET ?";
        try(Connection c=DriverManager.getConnection(url,user,pass);PreparedStatement p=c.prepareStatement(sql)){
            int i=1;if(!event.isEmpty())p.setString(i++,event);p.setInt(i++,limit);p.setInt(i,offset);
            List<String[]> rows=new ArrayList<>();try(ResultSet r=p.executeQuery()){while(r.next())rows.add(new String[]{r.getString(1),r.getString(2),r.getString(3),r.getString(4)});}return rows;
        }
    }
}
