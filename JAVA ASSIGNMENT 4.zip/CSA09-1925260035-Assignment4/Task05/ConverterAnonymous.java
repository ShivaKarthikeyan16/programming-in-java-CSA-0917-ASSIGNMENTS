import java.awt.*; import java.awt.event.*; import javax.swing.*;
public class ConverterAnonymous extends JFrame {
 private final JTextField amount=new JTextField(10); private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"}); private final JLabel result=new JLabel(" ");
 private void convert(){try{double v=Double.parseDouble(amount.getText());if(v<0)throw new NumberFormatException();double r=v*(((String)target.getSelectedItem()).equals("USD")?.012:.011);result.setText(String.format("%.2f",r));}catch(Exception ex){result.setText("Invalid amount");}}
 public ConverterAnonymous(){super("Converter - Anonymous");setLayout(new FlowLayout());JButton b=new JButton("Convert");ActionListener h=new ActionListener(){public void actionPerformed(ActionEvent e){convert();}};b.addActionListener(h);amount.addActionListener(h);add(amount);add(target);add(b);add(result);setDefaultCloseOperation(EXIT_ON_CLOSE);pack();}
 public static void main(String[] a){SwingUtilities.invokeLater(()->new ConverterAnonymous().setVisible(true));}
}
