import java.awt.*; import java.awt.event.*; import javax.swing.*;
public class ConverterFrameListener extends JFrame implements ActionListener {
 private final JTextField amount=new JTextField(10); private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"}); private final JLabel result=new JLabel(" ");
 public ConverterFrameListener(){ super("Converter - Frame Listener"); setLayout(new FlowLayout()); JButton b=new JButton("Convert"); add(amount);add(target);add(b);add(result);b.addActionListener(this);amount.addActionListener(this);setDefaultCloseOperation(EXIT_ON_CLOSE);pack();}
 public void actionPerformed(ActionEvent e){ try{double v=Double.parseDouble(amount.getText());if(v<0)throw new NumberFormatException();double r=v*(((String)target.getSelectedItem()).equals("USD")?.012:.011);result.setText(String.format("%.2f",r));}catch(Exception ex){result.setText("Invalid amount");}}
 public static void main(String[] a){SwingUtilities.invokeLater(()->new ConverterFrameListener().setVisible(true));}
}
