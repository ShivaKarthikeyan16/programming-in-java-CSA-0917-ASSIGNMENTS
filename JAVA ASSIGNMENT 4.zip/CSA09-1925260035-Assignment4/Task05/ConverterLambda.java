import java.awt.*; import java.awt.event.*; import javax.swing.*;
public class ConverterLambda extends JFrame {
 private final JTextField amount=new JTextField(10);
 private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"});
 private final JLabel result=new JLabel(" ");
 private static double rate(String c){ return c.equals("USD")?0.012:0.011; }
 public ConverterLambda(){
  super("Currency Converter"); setLayout(new FlowLayout());
  JButton button=new JButton("Convert");
  add(new JLabel("INR")); add(amount); add(target); add(button); add(result);
  ActionListener action=e->convert();
  button.addActionListener(action); amount.addActionListener(action);
  setDefaultCloseOperation(EXIT_ON_CLOSE); pack(); setLocationRelativeTo(null);
 }
 private void convert(){
  try { double v=Double.parseDouble(amount.getText().trim());
   if(!Double.isFinite(v)||v<0) throw new NumberFormatException();
   double out=v*rate((String)target.getSelectedItem());
   result.setText(String.format("%.2f",(Object)out));
   JOptionPane.showMessageDialog(this,String.format("Converted amount: %.2f",out));
  } catch(NumberFormatException ex){ result.setText("Invalid amount"); }
 }
 public static void main(String[] a){ SwingUtilities.invokeLater(()->new ConverterLambda().setVisible(true)); }
}
