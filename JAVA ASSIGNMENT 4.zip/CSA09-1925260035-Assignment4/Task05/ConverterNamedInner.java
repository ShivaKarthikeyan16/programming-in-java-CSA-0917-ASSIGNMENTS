import java.awt.*; import java.awt.event.*; import javax.swing.*;
public class ConverterNamedInner extends JFrame {
 private final JTextField amount=new JTextField(10); private final JComboBox<String> target=new JComboBox<>(new String[]{"USD","EUR"}); private final JLabel result=new JLabel(" ");
 private class ConvertHandler implements ActionListener { public void actionPerformed(ActionEvent e){convert();} }
 private void convert(){try{double v=Double.parseDouble(amount.getText());if(v<0)throw new NumberFormatException();double r=v*(((String)target.getSelectedItem()).equals("USD")?.012:.011);result.setText(String.format("%.2f",r));}catch(Exception ex){result.setText("Invalid amount");}}
 public ConverterNamedInner(){super("Converter - Named Inner");setLayout(new FlowLayout());JButton b=new JButton("Convert");ConvertHandler h=new ConvertHandler();b.addActionListener(h);amount.addActionListener(h);add(amount);add(target);add(b);add(result);setDefaultCloseOperation(EXIT_ON_CLOSE);pack();}
 public static void main(String[] a){SwingUtilities.invokeLater(()->new ConverterNamedInner().setVisible(true));}
}
