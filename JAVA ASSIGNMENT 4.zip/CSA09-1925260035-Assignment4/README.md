# CSA09 Assignment 4 — Event-Driven GUI Design

Student: D Shiva Karthikeyan  
Register Number: 1925260035  
Repository: `CSA09-1925260035-Assignment4`  
Language: Java (JDK 17 recommended; Swing/AWT)

## Structure
- Task01: FeeWindow and FeeService (separation of UI and service)
- Task02: event model, component hierarchy, pseudocode and lifecycle trace are in the report
- Task03: LibrarySearchScreen (nested BorderLayout/FlowLayout)
- Task04: DrawPad (correct mouseClicked override and persistent repaint)
- Task05: four event-handler styles; ConverterLambda includes Enter-key handling
- Task06: layered Swing/JDBC registration application and SQL schema
- Screenshots: illustrative UI previews. Capture actual execution screenshots on your machine before final submission.

## Compile and run
Compile a task from its folder:
`javac -d out Task04/DrawPad.java`
`java -cp out DrawPad`

For Task 3:
`javac -d out Task03/LibrarySearchScreen.java`
`java -cp out LibrarySearchScreen`

For Task 5, compile and run any one class, e.g.:
`javac -d out Task05/ConverterLambda.java`
`java -cp out ConverterLambda`

Task 1 and Task 6 use JDBC. Add the MySQL Connector/J JAR to the classpath and configure:
- `DB_URL` (default `jdbc:mysql://localhost:3306/college` for Task01; `jdbc:mysql://localhost:3306/campus_events` for Task06)
- `DB_USER`
- `DB_PASSWORD`

Run Task06 SQL first: `mysql -u root -p < SQL/schema.sql`

## Important
The Task06 DAO uses a database UNIQUE constraint on `(student_id, event_name)` to prevent duplicate registrations even when two requests arrive concurrently. Database work is run in SwingWorker, not on the Swing event-dispatch thread. Add pagination controls if extending beyond the required first-page filter demonstration.

Commit progressively: one or more meaningful commits per task. Replace the cover-page GitHub placeholder with your actual repository URL.
