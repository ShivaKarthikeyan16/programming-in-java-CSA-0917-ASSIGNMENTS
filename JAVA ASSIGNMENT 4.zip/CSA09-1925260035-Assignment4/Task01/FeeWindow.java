import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class FeeWindow extends JFrame {
    private final JTextField regNo=new JTextField(14), amount=new JTextField(10);
    private final FeeService service=new FeeService(
        System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/college"),
        System.getenv().getOrDefault("DB_USER","root"),
        System.getenv().getOrDefault("DB_PASSWORD",""));
    public FeeWindow() {
        super("Student Fee Payment");
        setLayout(new GridLayout(4,2,8,8));
        add(new JLabel("Register number")); add(regNo);
        add(new JLabel("Amount")); add(amount);
        JButton pay=new JButton("Pay"), clear=new JButton("Clear"), receipt=new JButton("Receipt");
        add(pay); add(clear); add(receipt); add(new JLabel("Enter details and choose an action."));
        pay.addActionListener(e -> pay());
        clear.addActionListener(e -> { regNo.setText(""); amount.setText(""); });
        receipt.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Receipt is available after a successful payment. Check the payment record."));
        addWindowListener(new WindowAdapter(){ public void windowClosing(WindowEvent e){ dispose(); }});
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); pack(); setLocationRelativeTo(null);
    }
    private void pay() {
        try { service.pay(regNo.getText(),amount.getText());
            JOptionPane.showMessageDialog(this,"Payment recorded successfully.");
        } catch (Exception ex) { JOptionPane.showMessageDialog(this,ex.getMessage(),"Payment error",JOptionPane.ERROR_MESSAGE); }
    }
    public static void main(String[] args){ SwingUtilities.invokeLater(() -> new FeeWindow().setVisible(true)); }
}
