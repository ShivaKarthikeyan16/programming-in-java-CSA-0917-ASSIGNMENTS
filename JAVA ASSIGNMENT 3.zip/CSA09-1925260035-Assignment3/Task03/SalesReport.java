import java.io.*;
import java.nio.file.*;
import java.util.*;

public class SalesReport {
    static List<String> readManual(List<Path> files) {
        List<String> rows = new ArrayList<>();
        for (Path p : files) {
            BufferedReader br = null;
            try {
                br = Files.newBufferedReader(p);
                String line;
                while ((line = br.readLine()) != null) rows.add(line);
            } catch (IOException e) {
                System.out.println("Manual read failed at " + p.getFileName() + ": " + e.getMessage());
            } finally {
                if (br != null) try { br.close(); } catch (IOException e) {
                    System.out.println("Close failed: " + e.getMessage());
                }
            }
        }
        return rows;
    }

    static List<String> readWithResources(List<Path> files) {
        List<String> rows = new ArrayList<>();
        for (Path p : files) {
            try (BufferedReader br = Files.newBufferedReader(p)) {
                String line;
                while ((line = br.readLine()) != null) rows.add(line);
            } catch (IOException e) {
                System.out.println("TWR read failed at " + p.getFileName() + ": " + e.getMessage());
            }
        }
        return rows;
    }

    static void writeReport(Path out, List<String> rows) throws IOException {
        try (BufferedWriter bw = Files.newBufferedWriter(out)) {
            bw.write("DAILY SALES SUMMARY");
            bw.newLine();
            for (String row : rows) { bw.write(row); bw.newLine(); }
            bw.write("Rows processed: " + rows.size());
        }
    }

    public static void main(String[] args) throws Exception {
        Path dir = Paths.get("input");
        Files.createDirectories(dir);
        List<Path> files = new ArrayList<>();
        for (int i = 1; i <= 3; i++) {
            Path f = dir.resolve("store" + i + ".txt");
            Files.write(f, Arrays.asList("Store " + i + ": sales=" + (i * 100)));
            files.add(f);
        }
        Path missing = dir.resolve("store_missing.txt");
        List<Path> testFiles = new ArrayList<>(files);
        testFiles.add(missing);
        List<String> manual = readManual(testFiles);
        List<String> safe = readWithResources(testFiles);
        writeReport(Paths.get("manual-report.txt"), manual);
        writeReport(Paths.get("twr-report.txt"), safe);
        System.out.println("Manual rows: " + manual.size());
        System.out.println("Try-with-resources rows: " + safe.size());
        System.out.println("Reports written. Missing file was logged; processing continued.");
    }
}
