# CSA09 Assignment 3 – Exception Handling & Multithreading

**Student A:** D Shiva Karthikeyan  
**Register Number:** 1925260035  
**Student B:** [Enter partner name and register number]  
**GitHub Repository:** [Paste actual GitHub repository URL]  
**Java:** Java 17 or later

## Compile and run
In each task folder:
```bash
javac ClassName.java
java ClassName
```
Task01 requires `card-reader.txt` in the working directory. Task03 and Task07 generate demonstration input files automatically.

## Task summary
- Task01: ATM validation, checked/unchecked exceptions, multi-catch and finally.
- Task02: User-defined checked exceptions and exception chaining.
- Task03: Manual resource closing and try-with-resources.
- Task04: Thread and Runnable station simulation using start, sleep and join.
- Task05: Synchronized cinema seat booking.
- Task06: Bounded producer-consumer buffer and deadlock prevention.
- Task07: Fault-tolerant processing using ExecutorService, Callable, Future and ConcurrentLinkedQueue.

Each task folder contains source code, console output and an execution screenshot. Replace Student B and GitHub placeholders before submitting. Commit each task progressively as required by the assignment.
