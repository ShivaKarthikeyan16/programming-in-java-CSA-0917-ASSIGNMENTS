import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ResultProcessor {
    static class Result {
        final String file; final boolean success; final int score; final String message;
        Result(String f, boolean ok, int s, String m) { file=f; success=ok; score=s; message=m; }
    }
    static class ScoreTask implements Callable<Result> {
        private final Path file;
        ScoreTask(Path file) { this.file = file; }
        public Result call() {
            try {
                String value = new String(Files.readAllBytes(file)).trim();
                int score = Integer.parseInt(value);
                if (score < 0 || score > 100) throw new IllegalArgumentException("Score outside 0-100");
                return new Result(file.getFileName().toString(), true, score, "OK");
            } catch (NoSuchFileException e) {
                return new Result(file.getFileName().toString(), false, 0, "MISSING");
            } catch (IOException | IllegalArgumentException e) {
                return new Result(file.getFileName().toString(), false, 0, "CORRUPT: " + e.getMessage());
            }
        }
    }
    public static void main(String[] args) throws Exception {
        Path dir = Paths.get("input/scores");
        Files.createDirectories(dir);
        int total = 10000;
        for (int i=0; i<total; i++) {
            Path f = dir.resolve("score" + i + ".txt");
            if (i % 1000 == 0) Files.deleteIfExists(f);
            else if (i % 997 == 0) Files.write(f, "bad-score".getBytes());
            else Files.write(f, String.valueOf(i % 101).getBytes());
        }
        int[] pools = {1,2,4,8};
        for (int pool : pools) {
            long start = System.nanoTime();
            ExecutorService executor = Executors.newFixedThreadPool(pool);
            ConcurrentLinkedQueue<Result> results = new ConcurrentLinkedQueue<>();
            List<Future<Result>> futures = new ArrayList<>();
            for (int i=0; i<total; i++) {
                final Path f = dir.resolve("score" + i + ".txt");
                futures.add(executor.submit(new ScoreTask(f)));
            }
            for (Future<Result> future : futures) {
                try { results.add(future.get()); }
                catch (ExecutionException e) { results.add(new Result("unknown", false, 0, "UNEXPECTED")); }
            }
            executor.shutdown();
            int ok=0, fail=0, sum=0;
            for (Result r : results) { if (r.success) {ok++; sum+=r.score;} else fail++; }
            long ms = (System.nanoTime()-start)/1_000_000;
            System.out.println("Pool=" + pool + " | Success=" + ok + " | Failed=" + fail +
                               " | ScoreSum=" + sum + " | TimeMs=" + ms);
        }
        System.out.println("Expected total files: " + total + "; summary total must equal 10000.");
    }
}
