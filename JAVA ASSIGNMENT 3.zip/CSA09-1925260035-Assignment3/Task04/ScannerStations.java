public class ScannerStations {
    static class Station extends Thread {
        private final int scripts;
        Station(String name, int scripts) { super(name); this.scripts = scripts; }
        public void run() {
            try {
                System.out.println(getName() + " started");
                Thread.sleep(80 + (int)(Math.random() * 180));
                System.out.println(getName() + " scanned " + scripts + " scripts");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println(getName() + " interrupted");
            }
        }
    }
    static class RunnableStation implements Runnable {
        private final String name; private final int scripts;
        RunnableStation(String name, int scripts) { this.name = name; this.scripts = scripts; }
        public void run() {
            try {
                System.out.println(name + " (Runnable) started");
                Thread.sleep(70 + (int)(Math.random() * 160));
                System.out.println(name + " (Runnable) scanned " + scripts + " scripts");
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }
    public static void main(String[] args) throws InterruptedException {
        System.out.println("ANSWER-SCRIPT SCANNING");
        Station[] stations = {
            new Station("Station-1", 25), new Station("Station-2", 30),
            new Station("Station-3", 20), new Station("Station-4", 25)
        };
        for (Station s : stations) s.start();
        for (Station s : stations) s.join();
        System.out.println("All Thread stations completed. Total = 100");
        Thread r = new Thread(new RunnableStation("Station-5", 10));
        r.start(); r.join();
        System.out.println("All scanning tasks completed.");
    }
}
