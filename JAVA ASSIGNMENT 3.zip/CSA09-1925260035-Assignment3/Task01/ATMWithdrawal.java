import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ATMWithdrawal {
    static final double BALANCE = 5000.0;

    static void withdraw(String account, int amount) throws FileNotFoundException {
        if (account == null || !account.matches("\\d{8}"))
            throw new IllegalArgumentException("Account number must contain 8 digits.");
        if (amount <= 0)
            throw new IllegalArgumentException("Withdrawal amount must be positive.");
        if (amount > BALANCE)
            throw new ArithmeticException("Insufficient balance.");
        File cardReader = new File("card-reader.txt");
        if (!cardReader.exists())
            throw new FileNotFoundException("Card-reader file is missing.");
        System.out.println("Cash dispensed: Rs." + amount);
    }

    public static void main(String[] args) {
        System.out.println("ATM WITHDRAWAL TEST");
        String[][] tests = {
            {"12345678", "1000"},
            {"12AB5678", "500"},
            {"12345678", "-200"},
            {"12345678", "6000"},
            {"12345678", "500"}
        };
        for (int i = 0; i < tests.length; i++) {
            System.out.println("\nTest " + (i + 1) + ": account=" + tests[i][0] + ", amount=" + tests[i][1]);
            try {
                withdraw(tests[i][0], Integer.parseInt(tests[i][1]));
            } catch (NumberFormatException e) {
                System.out.println("Input error: amount must be numeric.");
            } catch (IllegalArgumentException | ArithmeticException e) {
                System.out.println("Validation error: " + e.getMessage());
            } catch (FileNotFoundException e) {
                System.out.println("System error: " + e.getMessage());
            } finally {
                System.out.println("Transaction attempt finished.");
            }
        }
    }
}
