public class SeatBooking {
    private final boolean[] booked;
    private int bookingsMade = 0;
    SeatBooking(int seats) { booked = new boolean[seats]; }

    public synchronized boolean book(int seat) {
        if (seat < 0 || seat >= booked.length) return false;
        if (booked[seat]) return false;
        booked[seat] = true;
        bookingsMade++;
        return true;
    }

    public static void main(String[] args) throws InterruptedException {
        SeatBooking screen = new SeatBooking(10);
        Thread[] users = new Thread[100];
        int[] successful = new int[100];
        for (int i = 0; i < users.length; i++) {
            final int id = i;
            final int seat = i % 10;
            users[i] = new Thread(() -> { if (screen.book(seat)) successful[id] = 1; });
            users[i].start();
        }
        for (Thread t : users) t.join();
        int accepted = 0;
        for (int v : successful) accepted += v;
        System.out.println("Successful bookings: " + accepted);
        System.out.println("Seats sold: " + screen.bookingsMade);
        System.out.println("Double bookings: " + (accepted - screen.bookingsMade));
    }
}
