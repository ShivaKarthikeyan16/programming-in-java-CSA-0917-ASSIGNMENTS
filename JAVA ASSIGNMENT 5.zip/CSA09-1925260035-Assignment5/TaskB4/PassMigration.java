import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.*;
public class PassMigration {
    public static void main(String[] args)throws Exception{
        Path input=Path.of(args.length>0?args[0]:"passes.txt");
        String url=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/pass_test");
        int loaded=0,failed=0;
        try(Connection c=DriverManager.getConnection(url,System.getenv().getOrDefault("DB_USER","root"),System.getenv().getOrDefault("DB_PASSWORD",""))){
            boolean old=c.getAutoCommit();c.setAutoCommit(false);
            String sql="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
            try(BufferedReader r=Files.newBufferedReader(input,StandardCharsets.UTF_8);
                PreparedStatement p=c.prepareStatement(sql)){
                String line;int batch=0;
                while((line=r.readLine())!=null){
                    try{
                        String[] f=line.split("\\|",-1);
                        if(f.length!=7)throw new IllegalArgumentException("Expected 7 fields");
                        p.setString(1,f[0]);p.setString(2,f[1]);p.setString(3,f[2]);
                        p.setInt(4,Integer.parseInt(f[3]));p.setDouble(5,Double.parseDouble(f[6]));
                        p.addBatch();batch++;loaded++;
                        if(batch==1000){p.executeBatch();batch=0;}
                    }catch(RuntimeException ex){failed++;System.err.println("Rejected: "+line+" | "+ex.getMessage());}
                }
                if(batch>0)p.executeBatch();c.commit();
            }catch(Exception ex){c.rollback();throw ex;}finally{c.setAutoCommit(old);}
            DatabaseMetaData md=c.getMetaData();
            System.out.println("Database: "+md.getDatabaseProductName()+" "+md.getDatabaseProductVersion());
            System.out.println("Driver: "+md.getDriverName()+" "+md.getDriverVersion());
            try(ResultSet tables=md.getTables(c.getCatalog(),null,"%",new String[]{"TABLE"})){
                System.out.println("Tables:");while(tables.next())System.out.println(" - "+tables.getString("TABLE_NAME"));
            }
        }
        System.out.println("Accepted records: "+loaded+"; rejected records: "+failed);
    }
}
