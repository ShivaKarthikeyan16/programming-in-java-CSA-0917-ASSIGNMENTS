# A1 — Bus-pass file format
## Delimited text format
Use UTF-8, one record per line, pipe-delimited fields in this order: passId | regNo | name | routeNo | boardingStop | validityDate | amountPaid. Escape backslash as `\\`, pipe as `\|`, newline as `\n`, and carriage return as `\r`. Decode escapes before interpreting fields. Validate exactly seven fields and numeric route/amount.
## Binary DataOutputStream format
Use a version byte, then length-prefixed UTF-8 strings (passId, regNo, name, boardingStop, validityDate), followed by int routeNo and double amountPaid. Length-prefixing avoids fixed-width truncation and supports delimiter characters naturally. A fixed-length RandomAccessFile alternative uses a fixed byte width per string plus int/double fields and computes offset = index × recordSize.
## Operations pseudocode
ADD(pass): validate fields; open BufferedWriter in CREATE+APPEND; write escaped fields and newline; flush/close; optionally force durable storage through FileChannel.force(true).
FIND(id): if file missing return NOT_FOUND; open BufferedReader; read line by line; parse and validate; skip/log malformed lines; return first matching pass ID; otherwise NOT_FOUND.
LIST(route): scan each line; parse/validate; append records with matching route; skip/log damaged rows; return list.
## Damaged data
A malformed field count, invalid integer/double, trailing escape or blank required ID marks a line damaged. Log line number and continue. Missing file should be reported as empty/not found, not treated as a crash. Append is not fully atomic under power loss: write to a temporary file and atomic rename for whole-file rewrites; for append, use checksums/record framing and fsync when stronger durability is required.
## Complexity
Text lookup/list is O(n) scan and O(1) extra memory for find (O(r) for returned route list). Fixed-size RandomAccessFile supports O(1) seek by record index, but lookup by pass ID still needs O(n) unless an index maps ID to offset. Fixed fields waste padding: wasted bytes per record = sum(field capacity − actual encoded length).
