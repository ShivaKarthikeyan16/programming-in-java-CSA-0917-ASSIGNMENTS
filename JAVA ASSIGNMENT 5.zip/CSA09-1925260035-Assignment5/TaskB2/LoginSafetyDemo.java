import java.sql.*;
public class LoginSafetyDemo {
    private static final String URL=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/pass_test");
    private static final String USER=System.getenv().getOrDefault("DB_USER","root");
    private static final String PASS=System.getenv().getOrDefault("DB_PASSWORD","");
    static boolean unsafe(Connection c,String id,String pwd)throws SQLException {
        String sql="SELECT * FROM users WHERE id='"+id+"' AND pwd='"+pwd+"'";
        try(Statement st=c.createStatement();ResultSet rs=st.executeQuery(sql)){return rs.next();}
    }
    static boolean safe(Connection c,String id,String pwd)throws SQLException {
        String sql="SELECT * FROM users WHERE id=? AND pwd=?";
        try(PreparedStatement ps=c.prepareStatement(sql)){
            ps.setString(1,id);ps.setString(2,pwd);
            try(ResultSet rs=ps.executeQuery()){return rs.next();}
        }
    }
    public static void main(String[] a)throws Exception {
        try(Connection c=DriverManager.getConnection(URL,USER,PASS)){
            String attack="' OR '1'='1' -- ";
            System.out.println("Unsafe crafted login accepted: "+unsafe(c,"nobody",attack));
            System.out.println("PreparedStatement crafted login accepted: "+safe(c,"nobody",attack));
        }
    }
}
