CREATE DATABASE IF NOT EXISTS pass_test;
USE pass_test;
DROP TABLE IF EXISTS users;
CREATE TABLE users(id VARCHAR(40) PRIMARY KEY, pwd VARCHAR(100) NOT NULL);
INSERT INTO users VALUES ('admin','correct-password'),('student','student-password');
