# CSA09 Assignment 5 — Data Persistence Engineering: Files and Databases
Student: D Shiva Karthikeyan | Register Number: 1925260035
Java: JDK 17+ recommended. JDBC tasks require MySQL Connector/J.

## Folder map
- TaskA1–TaskA5: design answers and pseudocode (Part A)
- TaskB1: PassStore, file benchmarks and growth benchmark
- TaskB2: SQL injection demonstration, local schema and damaged test file
- TaskB3: Statement/PreparedStatement/batch benchmark and transaction-safe PassLoader
- TaskB4: file-to-database migration and DatabaseMetaData inspection
- SQL: combined schema scripts
- Measurements: fill in actual measured results from your own machine/database
- Screenshots: add genuine execution screenshots

## Compile file tasks
`javac -d out TaskB1/BusPass.java TaskB1/PassStore.java`
`java -cp out PassStore`
`javac -d out TaskB1/BusPass.java TaskB1/PassStore.java TaskB1/FileReadBenchmark.java`
`java -cp out FileReadBenchmark`
`javac -d out TaskB1/BusPass.java TaskB1/PassStore.java TaskB1/PassGrowthBenchmark.java`
`java -cp out PassGrowthBenchmark`

## JDBC tasks
Add MySQL Connector/J to the classpath. Set DB_URL, DB_USER and DB_PASSWORD environment variables. Run TaskB2/schema.sql or TaskB3/schema.sql before the related programs. Example:
`javac -cp .;mysql-connector-j.jar TaskB3/PassLoader.java`
(Use `:` instead of `;` as the classpath separator on Linux/macOS.)
Run `StatementPreparedBatchBenchmark` after compiling it with the connector JAR.

## Evidence
Do not submit illustrative placeholders as measured evidence. Run the programs, save terminal output and screenshots, and fill the measurement tables in the report. JDBC timings depend on your computer, database, connector, network and MySQL configuration; no fabricated timing values are included.
