import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PassStore {
    private final Path file;
    public PassStore(Path file) { this.file=file; }

    // Delimiter is '|'. Backslash, pipe and newline are escaped to preserve field boundaries.
    private static String esc(String s) {
        return s.replace("\\","\\\\").replace("|","\\|").replace("\n","\\n").replace("\r","\\r");
    }
    private static List<String> split(String line) {
        List<String> out=new ArrayList<>(); StringBuilder field=new StringBuilder();
        boolean escape=false;
        for(char c:line.toCharArray()) {
            if(escape) { if(c=='n') field.append('\n'); else if(c=='r') field.append('\r'); else field.append(c); escape=false; }
            else if(c=='\\') escape=true;
            else if(c=='|') { out.add(field.toString()); field.setLength(0); }
            else field.append(c);
        }
        if(escape) throw new IllegalArgumentException("Trailing escape");
        out.add(field.toString()); return out;
    }
    private static String encode(BusPass p) {
        return String.join("|", esc(p.passId),esc(p.regNo),esc(p.name),
            Integer.toString(p.routeNo),esc(p.boardingStop),esc(p.validityDate),
            Double.toString(p.amountPaid));
    }
    private static BusPass decode(String line) {
        List<String> f=split(line);
        if(f.size()!=7) throw new IllegalArgumentException("Expected 7 fields");
        int route=Integer.parseInt(f.get(3)); double amount=Double.parseDouble(f.get(6));
        if(f.get(0).isBlank()||f.get(1).isBlank()||!Double.isFinite(amount)||amount<0)
            throw new IllegalArgumentException("Invalid field value");
        return new BusPass(f.get(0),f.get(1),f.get(2),route,f.get(4),f.get(5),amount);
    }
    public void add(BusPass pass) throws IOException {
        Path parent=file.toAbsolutePath().getParent();
        if(parent!=null) Files.createDirectories(parent);
        try(BufferedWriter w=Files.newBufferedWriter(file,StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,StandardOpenOption.APPEND)) {
            w.write(encode(pass)); w.newLine(); w.flush();
        }
    }
    /** Returns matching pass or null. Malformed rows are skipped and counted on stderr. */
    public BusPass find(String passId) throws IOException {
        if(!Files.exists(file)) return null;
        try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)) {
            String line; int lineNo=0;
            while((line=r.readLine())!=null) {
                lineNo++;
                try { BusPass p=decode(line); if(p.passId.equals(passId)) return p; }
                catch(RuntimeException ex) { System.err.println("Skipping damaged line "+lineNo+": "+ex.getMessage()); }
            }
        }
        return null;
    }
    public List<BusPass> listByRoute(int routeNo) throws IOException {
        List<BusPass> result=new ArrayList<>();
        if(!Files.exists(file)) return result;
        try(BufferedReader r=Files.newBufferedReader(file,StandardCharsets.UTF_8)) {
            String line; int lineNo=0;
            while((line=r.readLine())!=null) {
                lineNo++;
                try { BusPass p=decode(line); if(p.routeNo==routeNo) result.add(p); }
                catch(RuntimeException ex) { System.err.println("Skipping damaged line "+lineNo+": "+ex.getMessage()); }
            }
        }
        return result;
    }
    public static void main(String[] args) throws Exception {
        Path f=Files.createTempFile("passes",".txt");
        PassStore s=new PassStore(f);
        s.add(new BusPass("P1001","192311001","Arun",12,"Main Gate","2027-05-31",4500));
        s.add(new BusPass("P1002","192311002","A|B",12,"Library","2027-05-31",4200));
        Files.writeString(f,"P-DAMAGED|ONLY|THREE\n",StandardCharsets.UTF_8,StandardOpenOption.APPEND);
        s.add(new BusPass("P1003","192311003","Divya",7,"Hostel","2027-05-31",3800));
        System.out.println("Find P1003: "+s.find("P1003"));
        System.out.println("Find missing: "+s.find("P9999"));
        System.out.println("Route 12: "+s.listByRoute(12));
        Files.deleteIfExists(f);
    }
}
