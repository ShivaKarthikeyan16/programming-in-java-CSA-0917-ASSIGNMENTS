public class BusPass {
    public final String passId, regNo, name, boardingStop, validityDate;
    public final int routeNo;
    public final double amountPaid;
    public BusPass(String passId, String regNo, String name, int routeNo,
                   String boardingStop, String validityDate, double amountPaid) {
        this.passId=passId; this.regNo=regNo; this.name=name; this.routeNo=routeNo;
        this.boardingStop=boardingStop; this.validityDate=validityDate; this.amountPaid=amountPaid;
    }
    public String toString() {
        return passId+" | "+regNo+" | "+name+" | route "+routeNo+" | "+boardingStop+
               " | "+validityDate+" | "+amountPaid;
    }
}
