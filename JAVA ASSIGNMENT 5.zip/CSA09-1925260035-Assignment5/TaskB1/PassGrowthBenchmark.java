import java.nio.file.*;
public class PassGrowthBenchmark {
    public static void main(String[] args) throws Exception {
        int[] sizes={1000,10000,100000};
        for(int n:sizes) {
            Path p=Files.createTempFile("pass-growth",".txt"); PassStore s=new PassStore(p);
            for(int i=0;i<n;i++) s.add(new BusPass("P"+i,"R"+i,"Student"+i,i%20,"Stop","2027-05-31",4000));
            long t=System.nanoTime(); BusPass found=s.find("P"+(n-1)); long elapsed=System.nanoTime()-t;
            System.out.printf("records=%d, found=%s, lookup=%.3f ms, bytes=%d%n",n,found!=null,elapsed/1e6,Files.size(p));
            Files.delete(p);
        }
    }
}
