import java.io.*;
import java.nio.file.*;
public class FileReadBenchmark {
    static long countUnbuffered(Path p) throws IOException {
        long lines=0; try(InputStream in=Files.newInputStream(p)) {
            int b; while((b=in.read())!=-1) if(b=='\n') lines++;
        } return lines;
    }
    static long countBuffered(Path p) throws IOException {
        long lines=0; try(BufferedReader r=Files.newBufferedReader(p)) {
            while(r.readLine()!=null) lines++;
        } return lines;
    }
    static void generate(Path p,long bytes) throws IOException {
        byte[] block=("attendance-record-0123456789\n").getBytes();
        try(OutputStream out=new BufferedOutputStream(Files.newOutputStream(p))) {
            long written=0; while(written<bytes) { int n=(int)Math.min(block.length,bytes-written); out.write(block,0,n); written+=n; }
        }
    }
    public static void main(String[] args) throws Exception {
        long[] sizes={1L<<20,10L<<20,50L<<20};
        for(long size:sizes) {
            Path p=Files.createTempFile("attendance",".log"); generate(p,size);
            long t=System.nanoTime(); long a=countUnbuffered(p); long u=System.nanoTime()-t;
            t=System.nanoTime(); long b=countBuffered(p); long v=System.nanoTime()-t;
            System.out.printf("%d bytes | lines %d/%d | unbuffered %.3f ms | buffered %.3f ms%n",
                Files.size(p),a,b,u/1e6,v/1e6); Files.delete(p);
        }
    }
}
