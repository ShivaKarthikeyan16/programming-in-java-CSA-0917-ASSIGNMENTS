import java.sql.*;
import java.util.*;
public class PassLoader {
    /** Loads records in batches of 1,000 within one transaction. */
    public static int loadAll(Connection con,List<String[]> passes)throws SQLException {
        String sql="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
        boolean oldAutoCommit=con.getAutoCommit();
        con.setAutoCommit(false);
        int total=0;
        try(PreparedStatement ps=con.prepareStatement(sql)) {
            int batchCount=0;
            for(String[] p:passes) {
                if(p.length!=5) throw new IllegalArgumentException("Each pass needs 5 values");
                ps.setString(1,p[0]); ps.setString(2,p[1]); ps.setString(3,p[2]);
                ps.setInt(4,Integer.parseInt(p[3])); ps.setDouble(5,Double.parseDouble(p[4]));
                if(!Double.isFinite(Double.parseDouble(p[4]))||Double.parseDouble(p[4])<0)
                    throw new IllegalArgumentException("Invalid amount for "+p[0]);
                ps.addBatch(); batchCount++;
                if(batchCount==1000){ total+=sum(ps.executeBatch()); batchCount=0; }
            }
            if(batchCount>0) total+=sum(ps.executeBatch());
            con.commit();
            return total;
        } catch(SQLException|RuntimeException ex) {
            con.rollback();
            if(ex instanceof SQLException) throw (SQLException)ex;
            throw ex;
        } finally { con.setAutoCommit(oldAutoCommit); }
    }
    private static int sum(int[] counts) {
        int n=0; for(int x:counts) if(x==Statement.SUCCESS_NO_INFO)n++; else if(x>0)n+=x; return n;
    }
}
