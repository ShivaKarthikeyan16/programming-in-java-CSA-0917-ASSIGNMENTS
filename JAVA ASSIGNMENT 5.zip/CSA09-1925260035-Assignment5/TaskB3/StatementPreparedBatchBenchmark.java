import java.sql.*;
import java.util.*;
public class StatementPreparedBatchBenchmark {
    static List<String[]> make(int n){List<String[]> a=new ArrayList<>(n);for(int i=0;i<n;i++)a.add(new String[]{"P"+i,"R"+i,"Name"+i,Integer.toString(i%20),"4500.0"});return a;}
    static void clear(Connection c)throws SQLException{try(Statement s=c.createStatement()){s.executeUpdate("DELETE FROM bus_pass");}}
    static long statement(Connection c,List<String[]> rows)throws SQLException{
        clear(c);long t=System.nanoTime();
        try(Statement s=c.createStatement()){for(String[] r:rows)s.executeUpdate("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES('"+r[0]+"','"+r[1]+"','"+r[2]+"',"+r[3]+","+r[4]+")");}
        return System.nanoTime()-t;
    }
    static long prepared(Connection c,List<String[]> rows)throws SQLException{
        clear(c);long t=System.nanoTime();
        try(PreparedStatement p=c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)")){
            for(String[] r:rows){p.setString(1,r[0]);p.setString(2,r[1]);p.setString(3,r[2]);p.setInt(4,Integer.parseInt(r[3]));p.setDouble(5,Double.parseDouble(r[4]));p.executeUpdate();}
        }return System.nanoTime()-t;
    }
    static long batch(Connection c,List<String[]> rows)throws SQLException{
        clear(c);boolean old=c.getAutoCommit();c.setAutoCommit(false);long t=System.nanoTime();
        try(PreparedStatement p=c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)")){
            int k=0;for(String[] r:rows){p.setString(1,r[0]);p.setString(2,r[1]);p.setString(3,r[2]);p.setInt(4,Integer.parseInt(r[3]));p.setDouble(5,Double.parseDouble(r[4]));p.addBatch();if(++k%1000==0)p.executeBatch();}
            p.executeBatch();c.commit();
        }catch(SQLException e){c.rollback();throw e;}finally{c.setAutoCommit(old);}
        return System.nanoTime()-t;
    }
    public static void main(String[] a)throws Exception{
        String url=System.getenv().getOrDefault("DB_URL","jdbc:mysql://localhost:3306/pass_test");
        try(Connection c=DriverManager.getConnection(url,System.getenv().getOrDefault("DB_USER","root"),System.getenv().getOrDefault("DB_PASSWORD",""))){
            for(int n:new int[]{1000,10000,100000}){List<String[]> rows=make(n);
                System.out.printf("%d rows: Statement %.2f ms; Prepared %.2f ms; Batch+transaction %.2f ms%n",
                    n,statement(c,rows)/1e6,prepared(c,rows)/1e6,batch(c,rows)/1e6);}
        }
    }
}
