import java.util.*;
public class HashContractTests {
 static class BrokenStudent {final String id;BrokenStudent(String s){id=s;}public boolean equals(Object o){return o instanceof BrokenStudent b&&id.equals(b.id);}}
 static final class Student {final String id,name;Student(String i,String n){id=i;name=n;}public boolean equals(Object o){return o instanceof Student s&&id.equals(s.id);}public int hashCode(){return Objects.hash(id);}public String toString(){return name+"("+id+")";}}
 static class MutableStudent {String id;MutableStudent(String s){id=s;}public boolean equals(Object o){return o instanceof MutableStudent m&&Objects.equals(id,m.id);}public int hashCode(){return Objects.hash(id);}}
 public static void main(String[]x){
  Set<BrokenStudent>b=new HashSet<>();b.add(new BrokenStudent("1925260035"));b.add(new BrokenStudent("1925260035"));System.out.println("Broken equals-only set size: "+b.size());
  Set<Student>s=new HashSet<>();s.add(new Student("1925260035","Shiva"));s.add(new Student("1925260035","Duplicate"));System.out.println("Corrected set size: "+s.size()+" "+s);
  MutableStudent m=new MutableStudent("REG-1");Set<MutableStudent>ms=new HashSet<>();ms.add(m);System.out.println("Before mutation contains: "+ms.contains(m));m.id="REG-2";System.out.println("After mutation contains: "+ms.contains(m)+" (hash-based lookup can fail)");
  Map<String,Student>attendance=new HashMap<>();attendance.put("1925260035",new Student("1925260035","Shiva"));System.out.println("Map de-duplication: "+attendance.containsKey("1925260035"));
 }
}
