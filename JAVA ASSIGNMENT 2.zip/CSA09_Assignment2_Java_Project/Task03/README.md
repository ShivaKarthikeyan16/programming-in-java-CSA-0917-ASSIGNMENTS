# Task03

Java implementation for Assignment 2 question 03. Compile and run with:

```bash
javac HashContractTests.java
java HashContractTests
```

Run locally and save your own genuine execution screenshot.
