# Task02

Java implementation for Assignment 2 question 02. Compile and run with:

```bash
javac PlaylistCollections.java
java PlaylistCollections
```

Run locally and save your own genuine execution screenshot.
