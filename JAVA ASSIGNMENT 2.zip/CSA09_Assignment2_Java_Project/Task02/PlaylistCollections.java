import java.util.*;
public class PlaylistCollections {
 public static void main(String[]x){
  List<String> playlist=new ArrayList<>(Arrays.asList("Song A","Song B","Song C","Song D"));
  System.out.println("Playlist using ArrayList:");for(int i=0;i<playlist.size();i++)System.out.println((i+1)+". "+playlist.get(i));
  LinkedList<String> linked=new LinkedList<>(playlist);linked.add(2,"Inserted Song");linked.removeFirst();System.out.println("LinkedList after insert/remove: "+linked);
  Deque<String> next=new ArrayDeque<>();next.addLast("Song E");next.addLast("Song F");next.addFirst("Urgent Request");System.out.println("Up Next: "+next);System.out.println("Playing: "+next.removeFirst());System.out.println("Remaining: "+next);
  System.out.println("ArrayList get O(1), append amortized O(1), front insert/remove O(n).");
  System.out.println("LinkedList indexed get O(n); insertion/removal O(1) when node is known.");
  System.out.println("ArrayDeque end operations amortized O(1); no indexed access.");
 }
}
