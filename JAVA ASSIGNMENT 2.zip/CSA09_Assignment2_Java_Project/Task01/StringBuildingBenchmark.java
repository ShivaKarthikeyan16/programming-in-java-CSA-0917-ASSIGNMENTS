import java.util.Locale;
public class StringBuildingBenchmark {
 static volatile int sink;
 static String withString(int n,int f){String all="";for(int t=0;t<n;t++){String s="";for(int i=0;i<f;i++)s=s+"field"+i+"="+(t+i)+";";all=all+s;}sink=all.length();return all;}
 static String withBuilder(int n,int f){StringBuilder all=new StringBuilder();for(int t=0;t<n;t++){StringBuilder s=new StringBuilder();for(int i=0;i<f;i++)s.append("field").append(i).append('=').append(t+i).append(';');all.append(s);}sink=all.length();return all.toString();}
 static String withBuffer(int n,int f){StringBuffer all=new StringBuffer();for(int t=0;t<n;t++){StringBuffer s=new StringBuffer();for(int i=0;i<f;i++)s.append("field").append(i).append('=').append(t+i).append(';');all.append(s);}sink=all.length();return all.toString();}
 static double avg(Runnable r){r.run();long total=0;for(int i=0;i<5;i++){long s=System.nanoTime();r.run();total+=System.nanoTime()-s;}return total/5e6;}
 public static void main(String[]x){int[][] w={{1,6},{10000,50},{1000,200}};System.out.println("Q1 - String construction benchmark (ms; run locally for your timings)");System.out.printf("%-18s %12s %15s %15s%n","Workload","String","StringBuilder","StringBuffer");for(int[]a:w){int n=a[0],f=a[1];System.out.printf(Locale.US,"%-18s %12.3f %15.3f %15.3f%n",n+" x "+f,avg(()->withString(n,f)),avg(()->withBuilder(n,f)),avg(()->withBuffer(n,f)));}}
}
