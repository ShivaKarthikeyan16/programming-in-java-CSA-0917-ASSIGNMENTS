# Task01

Java implementation for Assignment 2 question 01. Compile and run with:

```bash
javac StringBuildingBenchmark.java
java StringBuildingBenchmark
```

Run locally and save your own genuine execution screenshot.
