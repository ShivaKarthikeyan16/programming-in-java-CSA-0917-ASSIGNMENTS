# Task06

Java implementation for Assignment 2 question 06. Compile and run with:

```bash
javac PatientTriage.java
java PatientTriage
```

Run locally and save your own genuine execution screenshot.
