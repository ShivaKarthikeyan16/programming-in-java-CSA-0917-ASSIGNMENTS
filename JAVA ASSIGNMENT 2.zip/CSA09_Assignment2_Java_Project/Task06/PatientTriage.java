import java.util.*;
public class PatientTriage {
 static class Patient{final String name;final int severity;final long arrival;Patient(String n,int s,long a){if(s<1||s>5)throw new IllegalArgumentException("Severity 1-5 required");name=n;severity=s;arrival=a;}public String toString(){return name+"(S"+severity+")";}}
 public static void main(String[]x){Comparator<Patient>order=Comparator.comparingInt((Patient p)->p.severity).thenComparingLong(p->p.arrival);PriorityQueue<Patient>q=new PriorityQueue<>(order);
  String[]n={"Ravi","Meena","Kumar","Lata","John","Asha"};int[]s={3,1,1,2,3,5};for(int i=0;i<n.length;i++)q.add(new Patient(n[i],s[i],i));
  System.out.print("Treatment order: ");while(!q.isEmpty())System.out.print(q.poll()+(q.isEmpty()?"\\n":" "));
  System.out.println("PriorityQueue add/poll O(log n), peek O(1), space O(n).");System.out.println("Arrival counter preserves FIFO for equal severity.");System.out.println("Fairness: consider clinically approved ageing or reserved capacity to reduce starvation.");
 }
}
