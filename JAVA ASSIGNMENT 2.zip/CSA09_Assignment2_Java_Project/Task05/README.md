# Task05

Java implementation for Assignment 2 question 05. Compile and run with:

```bash
javac LeaderboardDemo.java
java LeaderboardDemo
```

Run locally and save your own genuine execution screenshot.
