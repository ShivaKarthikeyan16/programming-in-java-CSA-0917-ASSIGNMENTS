import java.util.*;
public class LeaderboardDemo {
 static class Team {final String name;final int points,gd;Team(String n,int p,int g){name=n;points=p;gd=g;}int points(){return points;}int gd(){return gd;}String name(){return name;}public String toString(){return name+"("+points+","+gd+")";}}
 static class Leaderboard<T>{final Comparator<? super T>order;Leaderboard(Comparator<? super T>c){order=c;}List<T>rank(List<? extends T>input){List<T>copy=new ArrayList<>(input);copy.sort(order);return copy;}}
 public static void main(String[]x){
  Comparator<Team>correct=Comparator.comparingInt(Team::points).reversed().thenComparing(Comparator.comparingInt(Team::gd).reversed()).thenComparing(Team::name);
  Leaderboard<Team>b=new Leaderboard<>(correct);
  List<Team>d1=Arrays.asList(new Team("Panthers",9,4),new Team("Cobras",6,1),new Team("Bisons",9,4),new Team("Eagles",9,6));
  List<Team>d2=Arrays.asList(new Team("Wolves",10,8),new Team("Tigers",12,5),new Team("Bears",12,7),new Team("Lions",12,5));
  System.out.println("Dataset 1: "+b.rank(d1));System.out.println("Dataset 2: "+b.rank(d2));
  List<Team>bad=new ArrayList<>(d1);bad.sort(Comparator.comparingInt(Team::points).reversed());System.out.println("Faulty comparator (points only): "+bad);
  System.out.println("Correct rule: points descending, goal difference descending, name ascending.");
 }
}
