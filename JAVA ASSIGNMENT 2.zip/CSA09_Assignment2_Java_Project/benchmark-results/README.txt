Sample outputs captured by compiling/running the included Java programs in the build environment. Timings vary by machine; rerun locally for your own evidence.
