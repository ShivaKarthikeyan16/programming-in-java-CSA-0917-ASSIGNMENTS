import java.util.*;
public class PlaylistRedesignBenchmark {
 static volatile int sink;
 static double listOps(int n){List<Integer>a=new ArrayList<>();for(int i=0;i<n;i++)a.add(i);long s=System.nanoTime();for(int i=0;i<n;i++)a.add(0,-i);for(int i=0;i<n;i++)a.remove(0);long e=System.nanoTime()-s;sink=a.size();return e/1e6;}
 static double dequeOps(int n){Deque<Integer>a=new ArrayDeque<>();for(int i=0;i<n;i++)a.addLast(i);long s=System.nanoTime();for(int i=0;i<n;i++)a.addFirst(-i);for(int i=0;i<n;i++)a.removeFirst();long e=System.nanoTime()-s;sink=a.size();return e/1e6;}
 public static void main(String[]x){System.out.println("Front operation benchmark (ms; local values vary)");System.out.printf("%-12s %14s %14s%n","Operations","ArrayList","ArrayDeque");for(int n:new int[]{1000,10000,100000}){listOps(1000);dequeOps(1000);System.out.printf(Locale.US,"%-12d %14.3f %14.3f%n",n,listOps(n),dequeOps(n));}System.out.println("ArrayDeque end operations amortized O(1); ArrayList front shifts O(n) per operation.");}
}
