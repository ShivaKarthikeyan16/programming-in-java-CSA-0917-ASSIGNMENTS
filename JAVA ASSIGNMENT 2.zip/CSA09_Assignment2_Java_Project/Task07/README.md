# Task07

Java implementation for Assignment 2 question 07. Compile and run with:

```bash
javac PlaylistRedesignBenchmark.java
java PlaylistRedesignBenchmark
```

Run locally and save your own genuine execution screenshot.
