# Task04

Java implementation for Assignment 2 question 04. Compile and run with:

```bash
javac PharmacyMaps.java
java PharmacyMaps
```

Run locally and save your own genuine execution screenshot.
