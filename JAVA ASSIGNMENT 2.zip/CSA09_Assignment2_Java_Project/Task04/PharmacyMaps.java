import java.util.*;
public class PharmacyMaps {
 static Map<String,Integer> fill(Map<String,Integer>m,int n){for(int i=1;i<=n;i++)m.put(String.format("MED%06d",i),10+i);return m;}
 static double getTime(Map<String,Integer>m,int n){long sum=0,s=System.nanoTime();for(int i=0;i<100000;i++)sum+=m.getOrDefault(String.format("MED%06d",i%n+1),0);long e=System.nanoTime()-s;if(sum==-1)System.out.println();return e/1e6;}
 public static void main(String[]x){
  Map<String,Integer>h=new HashMap<>(),t=new TreeMap<>(),l=new LinkedHashMap<>();String[]codes={"MED003","MED001","MED004","MED002"};for(int i=0;i<codes.length;i++){h.put(codes[i],20+i);t.put(codes[i],20+i);l.put(codes[i],20+i);}
  System.out.println("TreeMap sorted report: "+t);System.out.println("LinkedHashMap insertion-order report: "+l);System.out.println("HashMap lookup MED001: "+h.get("MED001"));
  System.out.println("100,000 lookups (ms; local values vary)");System.out.printf("%-12s %10s %10s %15s%n","Size","HashMap","TreeMap","LinkedHashMap");
  for(int n:new int[]{1000,10000,100000}){Map<String,Integer>a=fill(new HashMap<>(),n),b=fill(new TreeMap<>(),n),c=fill(new LinkedHashMap<>(),n);getTime(a,n);getTime(b,n);getTime(c,n);System.out.printf(Locale.US,"%-12d %10.3f %10.3f %15.3f%n",n,getTime(a,n),getTime(b,n),getTime(c,n));}
 }
}
