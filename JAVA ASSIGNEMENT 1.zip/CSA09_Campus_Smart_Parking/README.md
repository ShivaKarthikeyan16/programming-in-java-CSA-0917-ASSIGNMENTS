# Campus Smart-Parking System (Java)

## Student details
- Name: [Enter your full name]
- Register number: [Enter your register number]
- Course: [Enter course / section]
- Java version: Java 17 or later

## Compile and run
From the project root:

```bash
javac -d out $(find src -name "*.java")
java -cp out parking.app.Main
```

On Windows PowerShell, compile with:
```powershell
Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { $_.FullName } | Set-Content sources.txt
javac -d out @sources.txt
java -cp out parking.app.Main
```

## Folder structure
- `src/parking/model`: domain objects, vehicle categories, users and tickets
- `src/parking/pricing`: interchangeable pricing strategies
- `src/parking/service`: parking facility operations
- `src/parking/app`: executable demonstration
- `task03_complete_code`: exact standalone completion of the supplied allocation/release program

## Design notes
The final version uses a jagged array for floors with different capacities and a `HashMap` for active tickets keyed by registration number. Pricing is separated behind `PricingPolicy`, so new vehicle categories and rules can be added without changing the parking facility. Update the student details before submission.

## Important
Run the programs yourself in your lab environment, capture genuine screenshots of compilation and output, and commit each task progressively to your own GitHub repository. Do not submit fabricated execution evidence.
