package parking.model;
public enum PassType { MONTHLY, ONE_DAY }
