package parking.model;
import parking.pricing.DeliveryVanPolicy;
public class DeliveryVan extends Vehicle {
    public DeliveryVan(String regNo) { super(regNo, new DeliveryVanPolicy(30.0)); }
}
