package parking.model;
import parking.pricing.FlatFeePolicy;
public class EBike extends Vehicle {
    public EBike(String regNo) { super(regNo, new FlatFeePolicy(25.0)); }
}
