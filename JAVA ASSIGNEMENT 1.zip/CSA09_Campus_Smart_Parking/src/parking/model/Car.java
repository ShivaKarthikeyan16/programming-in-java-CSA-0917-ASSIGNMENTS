package parking.model;
import parking.pricing.HourlyPolicy;
public class Car extends Vehicle {
    public Car(String regNo) { super(regNo, new HourlyPolicy(30.0, 300.0)); }
}
