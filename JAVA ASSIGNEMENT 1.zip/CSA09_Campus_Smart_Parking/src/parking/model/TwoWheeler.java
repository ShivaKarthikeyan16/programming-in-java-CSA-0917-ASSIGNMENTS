package parking.model;
import parking.pricing.HourlyPolicy;
public class TwoWheeler extends Vehicle {
    public TwoWheeler(String regNo) { super(regNo, new HourlyPolicy(10.0, 100.0)); }
}
