package parking.model;
import parking.pricing.HourlyPolicy;
public class ElectricCar extends Vehicle {
    private final double chargingRatePerKWh = 12.0;
    public ElectricCar(String regNo) { super(regNo, new HourlyPolicy(30.0, 300.0)); }
    public double chargingFee(double kWh) {
        if (kWh < 0) throw new IllegalArgumentException("Energy cannot be negative");
        return kWh * chargingRatePerKWh;
    }
}
