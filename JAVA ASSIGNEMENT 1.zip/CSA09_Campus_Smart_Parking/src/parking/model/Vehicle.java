package parking.model;
import parking.pricing.PricingPolicy;
import java.time.LocalDateTime;
import java.util.Objects;

/** Common vehicle state. Concrete vehicle categories supply a pricing strategy. */
public abstract class Vehicle {
    private final String registrationNumber;
    private final PricingPolicy pricingPolicy;

    protected Vehicle(String registrationNumber, PricingPolicy pricingPolicy) {
        if (registrationNumber == null || registrationNumber.isBlank())
            throw new IllegalArgumentException("Registration number is required");
        this.registrationNumber = registrationNumber.trim().toUpperCase();
        this.pricingPolicy = Objects.requireNonNull(pricingPolicy);
    }
    public final String getRegistrationNumber() { return registrationNumber; }
    public double calculateFee(LocalDateTime entry, LocalDateTime exit) {
        return pricingPolicy.calculate(entry, exit);
    }
    public String getCategory() { return getClass().getSimpleName(); }
    @Override public final boolean equals(Object other) {
        return other instanceof Vehicle && registrationNumber.equals(((Vehicle) other).registrationNumber);
    }
    @Override public final int hashCode() { return registrationNumber.hashCode(); }
    @Override public String toString() { return getCategory() + "[" + registrationNumber + "]"; }
}
