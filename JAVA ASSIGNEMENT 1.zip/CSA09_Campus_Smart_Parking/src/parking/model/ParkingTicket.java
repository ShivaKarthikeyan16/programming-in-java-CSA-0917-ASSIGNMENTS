package parking.model;
import java.time.LocalDateTime;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicLong;

/** Immutable ticket data. Ticket IDs are unique across facility instances in this JVM. */
public class ParkingTicket {
    private static final AtomicLong NEXT_ID = new AtomicLong(1000);
    private final String ticketNumber;
    private final Vehicle vehicle;
    private final ParkingUser user;
    private final int floor;
    private final int slot;
    private final LocalDateTime entryTime;

    public ParkingTicket(Vehicle vehicle, ParkingUser user, int floor, int slot, LocalDateTime entryTime) {
        this.ticketNumber = "PK" + NEXT_ID.incrementAndGet();
        this.vehicle = vehicle;
        this.user = user;
        this.floor = floor;
        this.slot = slot;
        this.entryTime = entryTime;
    }
    public String getTicketNumber() { return ticketNumber; }
    public Vehicle getVehicle() { return vehicle; }
    public ParkingUser getUser() { return user; }
    public int getFloor() { return floor; }
    public int getSlot() { return slot; }
    public LocalDateTime getEntryTime() { return entryTime; }
    public double calculateFee(LocalDateTime exitTime) {
        if (user.hasFreeMonthlyPass()) return 0.0;
        if (user.getCategory() == ParkingUser.Category.VISITOR && user.getPassType() == PassType.ONE_DAY)
            return 100.0;
        return vehicle.calculateFee(entryTime, exitTime);
    }
    public long durationMinutes(LocalDateTime exitTime) {
        return Math.max(0, Duration.between(entryTime, exitTime).toMinutes());
    }
}
