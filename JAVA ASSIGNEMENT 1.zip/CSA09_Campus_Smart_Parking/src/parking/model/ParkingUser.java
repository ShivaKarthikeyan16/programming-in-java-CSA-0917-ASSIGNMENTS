package parking.model;
public class ParkingUser {
    public enum Category { STUDENT, STAFF, VISITOR }
    private final String userId;
    private final Category category;
    private final PassType passType;

    public ParkingUser(String userId, Category category, PassType passType) {
        if (userId == null || userId.isBlank()) throw new IllegalArgumentException("User ID required");
        if (category == null) throw new IllegalArgumentException("Category required");
        this.userId = userId;
        this.category = category;
        this.passType = passType;
        if (category != Category.VISITOR && passType != PassType.MONTHLY)
            throw new IllegalArgumentException("Students and staff require a valid monthly pass");
    }
    public String getUserId() { return userId; }
    public Category getCategory() { return category; }
    public PassType getPassType() { return passType; }
    public boolean hasFreeMonthlyPass() {
        return category != Category.VISITOR && passType == PassType.MONTHLY;
    }
}
