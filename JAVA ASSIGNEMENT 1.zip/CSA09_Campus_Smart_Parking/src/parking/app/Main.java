package parking.app;
import parking.model.*;
import parking.service.ParkingFacility;
import java.time.LocalDateTime;

/** Deterministic demonstration of the final extensible design. */
public class Main {
    public static void main(String[] args) {
        ParkingFacility facility = new ParkingFacility(new int[]{2, 3, 2, 4, 3});
        LocalDateTime start = LocalDateTime.of(2026, 11, 15, 8, 0);

        ParkingTicket t1 = facility.enter(new TwoWheeler("TN01AA1111"),
                new ParkingUser("S101", ParkingUser.Category.STUDENT, PassType.MONTHLY), start);
        ParkingTicket t2 = facility.enter(new Car("TN02BB2222"),
                new ParkingUser("V201", ParkingUser.Category.VISITOR, PassType.ONE_DAY), start);
        ParkingTicket t3 = facility.enter(new EBike("TN03CC3333"),
                new ParkingUser("V202", ParkingUser.Category.VISITOR, null), start);
        ParkingTicket t4 = facility.enter(new DeliveryVan("TN04DD4444"),
                new ParkingUser("V203", ParkingUser.Category.VISITOR, null), start);

        System.out.println(t1.getTicketNumber() + " " + t1.getVehicle() + " slot=" + t1.getFloor() + "," + t1.getSlot());
        System.out.println(t2.getTicketNumber() + " " + t2.getVehicle() + " slot=" + t2.getFloor() + "," + t2.getSlot());
        System.out.println(t3.getTicketNumber() + " " + t3.getVehicle() + " slot=" + t3.getFloor() + "," + t3.getSlot());
        System.out.println(t4.getTicketNumber() + " " + t4.getVehicle() + " slot=" + t4.getFloor() + "," + t4.getSlot());

        LocalDateTime finish = start.plusHours(2);
        System.out.println("Student monthly pass fee = Rs " + facility.exit("TN01AA1111", finish));
        System.out.println("Visitor one-day pass fee = Rs " + facility.exit("TN02BB2222", finish));
        System.out.println("E-bike flat fee = Rs " + facility.exit("TN03CC3333", finish));
        System.out.println("Delivery van fee = Rs " + facility.exit("TN04DD4444", finish));
        System.out.println("Available slots = " + facility.getAvailableCount());
    }
}
