package parking.pricing;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;

/** Double the car rate for minutes falling within [09:00, 17:00); normal car rate otherwise. */
public class DeliveryVanPolicy implements PricingPolicy {
    private final double carRate;
    public DeliveryVanPolicy(double carRate) {
        if (carRate < 0) throw new IllegalArgumentException("Rate cannot be negative");
        this.carRate = carRate;
    }
    @Override public double calculate(LocalDateTime entry, LocalDateTime exit) {
        if (exit.isBefore(entry)) throw new IllegalArgumentException("Exit precedes entry");
        double total = 0;
        LocalDateTime cursor = entry;
        while (cursor.isBefore(exit)) {
            LocalDateTime nextHour = cursor.plusMinutes(1);
            boolean peak = !cursor.toLocalTime().isBefore(LocalTime.of(9,0))
                    && cursor.toLocalTime().isBefore(LocalTime.of(17,0));
            total += (peak ? 2.0 : 1.0) * carRate / 60.0;
            cursor = nextHour;
        }
        return Math.ceil(total * 100.0) / 100.0;
    }
    @Override public String description() { return "2x car rate from 09:00 to 17:00"; }
}
