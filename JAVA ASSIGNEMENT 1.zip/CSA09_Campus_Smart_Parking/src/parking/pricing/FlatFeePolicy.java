package parking.pricing;
import java.time.LocalDateTime;

/** Fixed charge independent of parking duration. */
public class FlatFeePolicy implements PricingPolicy {
    private final double flatFee;
    public FlatFeePolicy(double flatFee) {
        if (flatFee < 0) throw new IllegalArgumentException("Fee cannot be negative");
        this.flatFee = flatFee;
    }
    @Override public double calculate(LocalDateTime entry, LocalDateTime exit) { return flatFee; }
    @Override public String description() { return "Flat fee Rs " + flatFee; }
}
