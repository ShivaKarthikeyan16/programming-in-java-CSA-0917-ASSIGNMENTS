package parking.pricing;
import java.time.Duration;
import java.time.LocalDateTime;

/** Charges every started hour, with an optional daily cap. */
public class HourlyPolicy implements PricingPolicy {
    private final double ratePerHour;
    private final double dailyMaximum;

    public HourlyPolicy(double ratePerHour, double dailyMaximum) {
        if (ratePerHour < 0 || dailyMaximum < 0) throw new IllegalArgumentException("Rates cannot be negative");
        this.ratePerHour = ratePerHour;
        this.dailyMaximum = dailyMaximum;
    }

    @Override public double calculate(LocalDateTime entry, LocalDateTime exit) {
        long minutes = Math.max(0, Duration.between(entry, exit).toMinutes());
        long hours = (minutes + 59) / 60; // ceiling division; avoids integer truncation
        double raw = hours * ratePerHour;
        return dailyMaximum > 0 ? Math.min(raw, dailyMaximum) : raw;
    }
    @Override public String description() { return "Rs " + ratePerHour + " per started hour"; }
}
