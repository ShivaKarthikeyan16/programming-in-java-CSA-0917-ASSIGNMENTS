package parking.pricing;
import java.time.LocalDateTime;

/** Strategy interface: each pricing rule decides the parking charge. */
public interface PricingPolicy {
    double calculate(LocalDateTime entry, LocalDateTime exit);
    String description();
}
