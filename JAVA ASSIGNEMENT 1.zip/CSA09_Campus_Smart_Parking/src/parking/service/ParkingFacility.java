package parking.service;
import parking.model.*;
import java.time.LocalDateTime;
import java.util.*;

/** Facility owns a jagged floor/slot layout and active tickets indexed by registration. */
public class ParkingFacility {
    private final String[][] slots; // null means free; each floor may have a different capacity
    private final Map<String, ParkingTicket> activeTickets = new HashMap<>();

    public ParkingFacility(int[] slotsPerFloor) {
        if (slotsPerFloor == null || slotsPerFloor.length == 0) throw new IllegalArgumentException("At least one floor required");
        slots = new String[slotsPerFloor.length][];
        for (int f = 0; f < slotsPerFloor.length; f++) {
            if (slotsPerFloor[f] <= 0) throw new IllegalArgumentException("Each floor needs at least one slot");
            slots[f] = new String[slotsPerFloor[f]];
        }
    }

    public ParkingTicket enter(Vehicle vehicle, ParkingUser user, LocalDateTime time) {
        String reg = vehicle.getRegistrationNumber();
        if (activeTickets.containsKey(reg)) throw new IllegalArgumentException("Vehicle is already parked: " + reg);
        for (int f = 0; f < slots.length; f++) {
            for (int s = 0; s < slots[f].length; s++) {
                if (slots[f][s] == null) {
                    slots[f][s] = reg;
                    ParkingTicket ticket = new ParkingTicket(vehicle, user, f, s, time);
                    activeTickets.put(reg, ticket);
                    return ticket;
                }
            }
        }
        return null; // facility full
    }

    public double exit(String registrationNumber, LocalDateTime exitTime) {
        String key = registrationNumber.trim().toUpperCase();
        ParkingTicket ticket = activeTickets.remove(key);
        if (ticket == null) throw new IllegalArgumentException("No active ticket for " + key);
        slots[ticket.getFloor()][ticket.getSlot()] = null;
        return ticket.calculateFee(exitTime);
    }

    public boolean release(int floor, int slot) {
        if (floor < 0 || floor >= slots.length || slot < 0 || slot >= slots[floor].length || slots[floor][slot] == null)
            return false;
        String reg = slots[floor][slot];
        slots[floor][slot] = null;
        activeTickets.remove(reg);
        return true;
    }
    public int getAvailableCount() {
        int count = 0;
        for (String[] floor : slots) for (String slot : floor) if (slot == null) count++;
        return count;
    }
    public int getFloorCount() { return slots.length; }
    public int getActiveTicketCount() { return activeTickets.size(); }
}
